module SequentialGameLib

using ..GameTheoryLib

export Node, SequentialGame, find_subgames, find_spne, find_pne_sequential

"""
    Node
    
Represents a node in the game tree.
"""
mutable struct Node
    id::Int
    player::Int # 1, 2, ...; 0 for terminal
    info_set::Int # ID of information set
    actions::Vector{String}
    children::Dict{String, Node}
    payoffs::Vector{Float64} # Only for terminal nodes
    
    # Constructor for decision nodes
    function Node(id::Int, player::Int, info_set::Int, actions::Vector{String})
        new(id, player, info_set, actions, Dict{String, Node}(), Float64[])
    end
    
    # Constructor for terminal nodes
    function Node(id::Int, payoffs::Vector{Float64})
        new(id, 0, 0, String[], Dict{String, Node}(), payoffs)
    end
end

"""
    SequentialGame
"""
struct SequentialGame
    root::Node
    num_players::Int
    info_sets::Dict{Int, Vector{Int}} # info_set_id => list of node_ids
end

"""
    find_subgames(game::SequentialGame)
    
Returns a list of nodes that are roots of subgames.
A node is a root of a subgame if:
1. It is the only node in its information set.
2. For all its descendants, if a node is in an info set, all other nodes in that info set are also descendants.
"""
function find_subgames(game::SequentialGame)
    subgame_roots = Node[]
    all_nodes = collect_nodes(game.root)
    
    for node in all_nodes
        if node.player == 0 continue end # Terminal nodes aren't roots of subgames usually
        
        # Condition 1: Single node in info set
        if length(game.info_sets[node.info_set]) > 1
            continue
        end
        
        # Condition 2: No broken info sets
        descendants = collect_nodes(node)
        descendant_ids = Set([n.id for n in descendants])
        
        is_subgame = true
        for d in descendants
            if d.player == 0 continue end
            # All nodes in d's info set must be in the descendants set
            for sibling_id in game.info_sets[d.info_set]
                if !(sibling_id in descendant_ids)
                    is_subgame = false
                    break
                end
            end
            if !is_subgame break end
        end
        
        if is_subgame
            push!(subgame_roots, node)
        end
    end
    
    return subgame_roots
end

function collect_nodes(root::Node)
    nodes = [root]
    for child in values(root.children)
        append!(nodes, collect_nodes(child))
    end
    return nodes
end

"""
    find_spne(game::SequentialGame)
    
For perfect information games, uses backward induction.
Returns a mapping of node_id => optimal_action.
"""
function find_spne(game::SequentialGame)
    # Check if perfect information
    for (is_id, nodes) in game.info_sets
        if length(nodes) > 1
            error("SPNE via backward induction only implemented for perfect information games.")
        end
    end
    
    node_strategies = Dict{Int, String}()
    node_payoffs = Dict{Int, Vector{Float64}}()
    
    function backward_induction!(node::Node)
        if node.player == 0
            node_payoffs[node.id] = node.payoffs
            return node.payoffs
        end
        
        best_payoff = -Inf
        best_action = ""
        best_full_payoff = Float64[]
        
        for action in node.actions
            child_payoff = backward_induction!(node.children[action])
            if child_payoff[node.player] > best_payoff
                best_payoff = child_payoff[node.player]
                best_action = action
                best_full_payoff = child_payoff
            end
        end
        
        node_strategies[node.id] = best_action
        node_payoffs[node.id] = best_full_payoff
        return best_full_payoff
    end
    
    backward_induction!(game.root)
    return node_strategies
end

"""
    find_pne_sequential(game::SequentialGame)
    
Converts the sequential game to normal form and finds PNE.
"""
function find_pne_sequential(game::SequentialGame)
    # 1. Identify strategies for each player
    # A strategy for player i is a mapping from each of their info sets to an action.
    player_info_sets = Dict{Int, Vector{Int}}() # player_id => info_set_ids
    info_set_actions = Dict{Int, Vector{String}}() # info_set_id => actions
    
    all_nodes = collect_nodes(game.root)
    for n in all_nodes
        if n.player == 0 continue end
        if !haskey(player_info_sets, n.player)
            player_info_sets[n.player] = Int[]
        end
        if !(n.info_set in player_info_sets[n.player])
            push!(player_info_sets[n.player], n.info_set)
            info_set_actions[n.info_set] = n.actions
        end
    end
    
    # Generate strategy space
    player_strategies = []
    for p in 1:game.num_players
        p_info_sets = get(player_info_sets, p, Int[])
        if isempty(p_info_sets)
            push!(player_strategies, [Dict{Int, String}()])
            continue
        end
        
        # Combinations of actions for each info set
        actions_list = [info_set_actions[is] for is in p_info_sets]
        p_strats = []
        for combo in Iterators.product(actions_list...)
            strat = Dict{Int, String}()
            for (i, is_id) in enumerate(p_info_sets)
                strat[is_id] = combo[i]
            end
            push!(p_strats, strat)
        end
        push!(player_strategies, p_strats)
    end
    
    strategy_counts = [length(s) for s in player_strategies]
    
    # 2. Build payoff matrices
    payoffs = [zeros(Tuple(strategy_counts)) for _ in 1:game.num_players]
    
    for profile_idx in CartesianIndices(Tuple(strategy_counts))
        # Strategy profile
        profile = [player_strategies[p][profile_idx[p]] for p in 1:game.num_players]
        
        # Traverse tree to find terminal payoff
        curr = game.root
        while curr.player != 0
            action = profile[curr.player][curr.info_set]
            curr = curr.children[action]
        end
        
        for p in 1:game.num_players
            payoffs[p][profile_idx] = curr.payoffs[p]
        end
    end
    
    nf_game = NormalFormGame(strategy_counts, payoffs)
    pne_indices = find_pure_nash(nf_game)
    
    # Convert indices back to strategy descriptions
    readable_pne = []
    for idx in pne_indices
        pne_strat = [player_strategies[p][idx[p]] for p in 1:game.num_players]
        push!(readable_pne, pne_strat)
    end
    
    return readable_pne
end

end # module
