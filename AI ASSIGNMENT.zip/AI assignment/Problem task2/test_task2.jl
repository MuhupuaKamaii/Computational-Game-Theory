include("../GameTheoryLib.jl")
include("SequentialGameLib.jl")

using .GameTheoryLib
using .SequentialGameLib
using Test

function test_perfect_info()
    println("Testing Perfect Information Game...")
    
    # Simple Entry Game:
    # Player 1 (Entrant): Enter or Stay Out
    # If Stay Out: (0, 2)
    # If Enter: Player 2 (Incumbent) chooses Fight or Accede
    #   Fight: (-1, -1)
    #   Accede: (1, 1)
    
    n3_fight = Node(3, [-1.0, -1.0])
    n4_accede = Node(4, [1.0, 1.0])
    
    n2_incumbent = Node(2, 2, 2, ["Fight", "Accede"])
    n2_incumbent.children["Fight"] = n3_fight
    n2_incumbent.children["Accede"] = n4_accede
    
    n5_stayout = Node(5, [0.0, 2.0])
    
    n1_entrant = Node(1, 1, 1, ["Enter", "StayOut"])
    n1_entrant.children["Enter"] = n2_incumbent
    n1_entrant.children["StayOut"] = n5_stayout
    
    info_sets = Dict(1 => [1], 2 => [2])
    game = SequentialGame(n1_entrant, 2, info_sets)
    
    # 1. Subgames
    subgames = find_subgames(game)
    println("Subgame roots: ", [n.id for n in subgames])
    @test length(subgames) == 2 # Root and Incumbent node
    
    # 2. SPNE (Backward Induction)
    spne = find_spne(game)
    println("SPNE Strategy: ", spne)
    # Player 2 should Accede (1 > -1)
    # Player 1 should Enter (1 > 0)
    @test spne[2] == "Accede"
    @test spne[1] == "Enter"
    
    # 3. PNE (Normal Form)
    pne = find_pne_sequential(game)
    println("PNEs: ", pne)
    # Expected PNEs: 
    # 1. (Enter, Accede)
    # 2. (StayOut, Fight) - though this is not subgame perfect
    @test length(pne) >= 2
end

function test_imperfect_info()
    println("\nTesting Imperfect Information Game...")
    
    # Simple game with imperfect info:
    # Player 1 chooses L or R.
    # Player 2 doesn't know what P1 chose and chooses l or r.
    # Basically a simultaneous game in sequential form.
    
    # Terminals
    nLL = Node(5, [2.0, 2.0])
    nLR = Node(6, [0.0, 3.0])
    nRL = Node(7, [3.0, 0.0])
    nRR = Node(8, [1.0, 1.0])
    
    # Player 2 nodes in the same information set
    n2_L = Node(2, 2, 2, ["l", "r"])
    n2_L.children["l"] = nLL
    n2_L.children["r"] = nLR
    
    n2_R = Node(3, 2, 2, ["l", "r"])
    n2_R.children["l"] = nRL
    n2_R.children["r"] = nRR
    
    # Player 1 root
    n1 = Node(1, 1, 1, ["L", "R"])
    n1.children["L"] = n2_L
    n1.children["R"] = n2_R
    
    info_sets = Dict(1 => [1], 2 => [2, 3])
    game = SequentialGame(n1, 2, info_sets)
    
    # 1. Subgames
    subgames = find_subgames(game)
    println("Subgame roots (Imperfect): ", [n.id for n in subgames])
    # Only root should be a subgame root because P2 nodes are in same info set
    @test length(subgames) == 1
    @test subgames[1].id == 1
    
    # 2. PNE
    pne = find_pne_sequential(game)
    println("PNEs (Imperfect): ", pne)
    # This is essentially:
    #      l     r
    # L (2,2) (0,3)
    # R (3,0) (1,1)
    # No pure Nash? Let's see.
    # L -> 2 vs 3 (R better)
    # R -> 3 vs 1 (L better)
    # No pure Nash in this specific matrix.
    # Wait, let's check:
    # L: p2 plays l -> 2, p2 plays r -> 0.
    # R: p2 plays l -> 3, p2 plays r -> 1.
    # P1 always prefers R? 3 > 2, 1 > 0. Yes, R is dominant.
    # If P1 plays R, P2 prefers r (1 > 0).
    # So (R, r) should be PNE.
    @test length(pne) == 1
    @test pne[1][1][1] == "R"
    @test pne[1][2][2] == "r"
end

test_perfect_info()
test_imperfect_info()
println("\nAll Task 2 tests passed!")
