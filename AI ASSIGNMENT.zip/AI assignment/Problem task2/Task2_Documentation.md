# Task 2: Sequential Form Game Solver Documentation

This document describes the structure and implementation of the Sequential Form Game library developed for Task 2.

## **Overview**
The library allows for the representation of games in extensive (sequential) form, including support for **imperfect information** through information sets. It provides tools to identify subgames and solve for both Subgame Perfect Nash Equilibria (SPNE) and Pure Strategy Nash Equilibria (PNE).

---

## **Core Structure**
The implementation is contained in [SequentialGameLib.jl](file:///c:/Users/LENOVO%20X1%20TABLE/Documents/AI%20assignment/task2/SequentialGameLib.jl).

### **1. Game Representation**
- **`Node`**: Represents a state in the game tree.
  - Decision nodes specify the active `player`, an `info_set` ID, and available `actions`.
  - Terminal nodes store the final `payoffs` for all players.
- **`SequentialGame`**: Encapsulates the tree structure starting from a `root` node and tracks all `info_sets`.

### **2. Subgame Identification**
The `find_subgames` function identifies all valid subgames.
- **Criteria**: 
    1. A subgame must start at a single node that is the only member of its information set.
    2. It must contain all descendants of that node.
    3. It must respect information set boundaries (it cannot contain only a part of an information set).

### **3. Solution Concepts**
- **Subgame Perfect Nash Equilibrium (SPNE)**: 
    - Implemented using **Backward Induction** for perfect information games. 
    - It recursively determines the optimal action at each node, assuming players will play optimally in all future states.
- **Pure Strategy Nash Equilibrium (PNE)**: 
    - Implemented by converting the extensive form game into its **Normal Form** equivalent.
    - It generates the full strategy space for each player (a mapping of information sets to actions) and calculates the payoff matrix to find standard Nash equilibria.

---

## **File Organization**
- **[task2/SequentialGameLib.jl](file:///c:/Users/LENOVO%20X1%20TABLE/Documents/AI%20assignment/task2/SequentialGameLib.jl)**: The core library for sequential games.
- **[task2/test_task2.jl](file:///c:/Users/LENOVO%20X1%20TABLE/Documents/AI%20assignment/task2/test_task2.jl)**: Test suite containing:
    - **Simple Entry Game**: A perfect information game showing subgames and SPNE vs PNE.
    - **Simultaneous-Move Game**: Represented as a sequential game with imperfect information to test information set handling.

---

## **How to Run**
To execute the Task 2 tests, run:

```powershell
& "C:\Users\LENOVO X1 TABLE\AppData\Local\Programs\Julia-1.12.6\bin\julia.exe" task2/test_task2.jl
```
