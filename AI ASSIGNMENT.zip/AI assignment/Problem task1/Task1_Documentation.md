# Task 1: Normal Form Game Solver Documentation

This document describes the structure and implementation of the Normal Form Game library developed for Task 1.

## **Overview**
The library is designed to represent multi-player games in normal form and provide algorithms to find Nash Equilibria (NE). It is implemented in Julia and focuses on modularity and mathematical correctness.

---

## **Core Structure**
The implementation is contained in [GameTheoryLib.jl](file:///c:/Users/LENOVO%20X1%20TABLE/Documents/AI%20assignment/GameTheoryLib.jl).

### **1. Data Representation: `NormalFormGame`**
The `NormalFormGame` struct is the primary data structure used to define a game.
- **`num_players`**: Integer representing the number of participants.
- **`strategy_counts`**: A vector indicating how many strategies each player has.
- **`payoffs`**: A vector of N-dimensional arrays. Each array corresponds to a player and stores their payoffs for every possible combination of strategies (strategy profile).

**Key Feature**: It supports an arbitrary number of players and strategies by using Julia's powerful N-dimensional array indexing.

### **2. Pure Strategy Nash Equilibrium (PNE)**
The `find_pure_nash` function identifies all PNE for any multi-player game.
- **Algorithm**: It iterates through every possible strategy profile in the game.
- **Indifference Check**: For each profile, it checks if any player can improve their payoff by unilaterally changing their strategy. If no player can do so, the profile is marked as a Nash Equilibrium.

### **3. Mixed Strategy Nash Equilibrium (MNE)**
The `find_mixed_nash_2player` function solves for mixed equilibria in 2-player games.
- **Algorithm**: It uses **Support Enumeration**.
- **Indifference Equations**: It identifies potential "supports" (sets of strategies played with non-zero probability) and solves a system of linear equations where each player must be indifferent between all strategies in their support.
- **Validation**: After solving the equations, it verifies that:
    1. Probabilities are non-negative.
    2. No player has an incentive to deviate to a strategy outside the support (Best Response condition).

---

## **File Organization**
- **[GameTheoryLib.jl](file:///c:/Users/LENOVO%20X1%20TABLE/Documents/AI%20assignment/GameTheoryLib.jl)**: The main library module containing the game logic and solvers.
- **[test_task1.jl](file:///c:/Users/LENOVO%20X1%20TABLE/Documents/AI%20assignment/test_task1.jl)**: A comprehensive test suite that demonstrates the library using:
    - **Prisoner's Dilemma** (Symmetric game with 1 PNE)
    - **Battle of the Sexes** (Coordination game with 2 PNE and 1 MNE)
    - **Matching Pennies** (Zero-sum game with only MNE)
    - **Rock Paper Scissors** (3x3 Zero-sum game)

---

## **How to Run**
To execute the tests and see the solvers in action, run the following command in your terminal:

```powershell
& "C:\Users\LENOVO X1 TABLE\AppData\Local\Programs\Julia-1.12.6\bin\julia.exe" test_task1.jl
```
