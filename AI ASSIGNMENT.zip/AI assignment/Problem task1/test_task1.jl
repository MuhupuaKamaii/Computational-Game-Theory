include("GameTheoryLib.jl")
using .GameTheoryLib
using Test

function test_pne()
    println("Testing Pure Strategy Nash Equilibrium...")
    
    # Prisoner's Dilemma
    # Strategies: 1: Cooperate, 2: Defect
    # Payoffs:
    # (C, C) -> (3, 3)
    # (C, D) -> (0, 5)
    # (D, C) -> (5, 0)
    # (D, D) -> (1, 1)
    
    payoff1 = [3.0 0.0; 5.0 1.0]
    payoff2 = [3.0 5.0; 0.0 1.0]
    
    pd_game = NormalFormGame([2, 2], [payoff1, payoff2])
    
    pne = find_pure_nash(pd_game)
    println("Prisoner's Dilemma PNE: ", pne)
    # Expected: (2, 2) which is (Defect, Defect)
    @test length(pne) == 1
    @test pne[1] == (2, 2)
    
    # Battle of the Sexes
    # (B, B) -> (2, 1)
    # (B, S) -> (0, 0)
    # (S, B) -> (0, 0)
    # (S, S) -> (1, 2)
    
    payoff1_bos = [2.0 0.0; 0.0 1.0]
    payoff2_bos = [1.0 0.0; 0.0 2.0]
    
    bos_game = NormalFormGame([2, 2], [payoff1_bos, payoff2_bos])
    
    pne_bos = find_pure_nash(bos_game)
    println("Battle of the Sexes PNE: ", pne_bos)
    # Expected: (1, 1) and (2, 2)
    @test length(pne_bos) == 2
    @test (1, 1) in pne_bos
    @test (2, 2) in pne_bos
    
    # Rock Paper Scissors (No PNE)
    payoff1_rps = [0.0 -1.0 1.0; 1.0 0.0 -1.0; -1.0 1.0 0.0]
    payoff2_rps = [0.0 1.0 -1.0; -1.0 0.0 1.0; 1.0 -1.0 0.0]
    rps_game = NormalFormGame([3, 3], [payoff1_rps, payoff2_rps])
    pne_rps = find_pure_nash(rps_game)
    println("Rock Paper Scissors PNE: ", pne_rps)
    @test length(pne_rps) == 0
end

function test_mne()
    println("\nTesting Mixed Strategy Nash Equilibrium...")
    
    # Matching Pennies
    # (H, H) -> (1, -1)
    # (H, T) -> (-1, 1)
    # (T, H) -> (-1, 1)
    # (T, T) -> (1, -1)
    
    payoff1 = [1.0 -1.0; -1.0 1.0]
    payoff2 = [-1.0 1.0; 1.0 -1.0]
    
    mp_game = NormalFormGame([2, 2], [payoff1, payoff2])
    
    mne = find_mixed_nash_2player(mp_game)
    println("Matching Pennies MNE: ", mne)
    # Expected: ([0.5, 0.5], [0.5, 0.5])
    @test length(mne) >= 1
    p, q = mne[1]
    @test isapprox(p, [0.5, 0.5])
    @test isapprox(q, [0.5, 0.5])

    # Battle of the Sexes (should have 3 Nash equilibria: 2 pure, 1 mixed)
    payoff1_bos = [2.0 0.0; 0.0 1.0]
    payoff2_bos = [1.0 0.0; 0.0 2.0]
    bos_game = NormalFormGame([2, 2], [payoff1_bos, payoff2_bos])
    
    mne_bos = find_mixed_nash_2player(bos_game)
    println("Battle of the Sexes All Nash: ", mne_bos)
    @test length(mne_bos) == 3
    # One should be [2/3, 1/3] and [1/3, 2/3]
    # Check: 2*q1 + 0*q2 = 0*q1 + 1*q2 => 2q1 = q2. Since q1+q2=1, 3q1=1 => q1=1/3, q2=2/3
    # Check: 1*p1 + 0*p2 = 0*p1 + 2*p2 => p1 = 2p2. Since p1+p2=1, 3p2=1 => p2=1/3, p1=2/3
    found_mixed = false
    for (p, q) in mne_bos
        if isapprox(p, [2/3, 1/3]) && isapprox(q, [1/3, 2/3])
            found_mixed = true
        end
    end
    @test found_mixed
end

# Run tests
test_pne()
test_mne()
println("\nAll tests passed!")
