module GameTheoryLib

export NormalFormGame, find_pure_nash, find_mixed_nash_2player

"""
    NormalFormGame
    
Represents a multi-player game in normal form.
- `num_players`: Number of players.
- `strategy_counts`: A vector where the i-th element is the number of strategies for player i.
- `payoffs`: A vector of N-dimensional arrays. payoffs[i] contains the payoffs for player i.
"""
struct NormalFormGame
    num_players::Int
    strategy_counts::Vector{Int}
    payoffs::Vector{Array{Float64}}

    function NormalFormGame(strategy_counts::Vector{Int}, payoffs::AbstractVector)
        num_players = length(strategy_counts)
        if length(payoffs) != num_players
            error("Number of payoff arrays must match number of players.")
        end
        # Convert payoffs to Vector{Array{Float64}} to match struct field
        typed_payoffs = [convert(Array{Float64}, p) for p in payoffs]
        for i in 1:num_players
            if size(typed_payoffs[i]) != Tuple(strategy_counts)
                error("Payoff array for player $(i) has incorrect dimensions. Expected $(Tuple(strategy_counts)), got $(size(typed_payoffs[i])).")
            end
        end
        new(num_players, strategy_counts, typed_payoffs)
    end
end

"""
    find_pure_nash(game::NormalFormGame)

Returns a list of pure strategy Nash equilibria.
Each equilibrium is represented as a Tuple of strategy indices.
"""
function find_pure_nash(game::NormalFormGame)
    equilibria = []
    
    # Iterate through all possible strategy profiles
    # CartesianIndices creates a multi-dimensional iterator based on strategy counts
    for profile in CartesianIndices(Tuple(game.strategy_counts))
        is_nash = true
        
        for player_idx in 1:game.num_players
            current_payoff = game.payoffs[player_idx][profile]
            
            # Check all alternative strategies for this player
            for alt_strategy in 1:game.strategy_counts[player_idx]
                if alt_strategy == profile[player_idx]
                    continue
                end
                
                # Construct alternative profile
                alt_profile_vec = collect(profile.I)
                alt_profile_vec[player_idx] = alt_strategy
                alt_profile = CartesianIndex(Tuple(alt_profile_vec))
                
                if game.payoffs[player_idx][alt_profile] > current_payoff
                    is_nash = false
                    break
                end
            end
            
            if !is_nash
                break
            end
        end
        
        if is_nash
            push!(equilibria, profile.I)
        end
    end
    
    return equilibria
end

"""
    find_mixed_nash_2player(game::NormalFormGame)

Finds mixed strategy Nash equilibria for 2-player games using support enumeration.
Note: This is a simplified implementation for 2x2 games or small supports.
Returns a list of pairs of probability vectors.
"""
function find_mixed_nash_2player(game::NormalFormGame)
    if game.num_players != 2
        error("Mixed Nash solver currently only supports 2 players.")
    end

    # For 2-player games, payoffs are typically referred to as A and B
    A = game.payoffs[1]
    B = game.payoffs[2]
    
    m, n = game.strategy_counts
    equilibria = []

    # Support Enumeration Algorithm (Simplified)
    # We look for supports (S1, S2) such that |S1| = |S2| = k
    # For a given support, we solve the indifference equations.
    
    # Iterate through all possible support sizes k
    for k in 1:min(m, n)
        # Iterate through all combinations of strategies for player 1 of size k
        for s1_indices in combinations(1:m, k)
            # Iterate through all combinations of strategies for player 2 of size k
            for s2_indices in combinations(1:n, k)
                
                # Solve for p (player 1's mixed strategy over support s1)
                # such that player 2 is indifferent among strategies in s2
                # Σ p_i * B[i, j] = v for all j in s2, and Σ p_i = 1
                
                # Equations for p:
                # p' * B_sub = v * [1...1]
                # p' * [1...1] = 1
                
                # Sub-matrices
                B_sub = B[s1_indices, s2_indices]
                A_sub = A[s1_indices, s2_indices]
                
                # To find p (player 1's strategy):
                # Solve p' * B_sub[:, j] = v2 for all j in s2
                # This is equivalent to B_sub' * p = v2 * 1
                
                # Linear system for p:
                # [ B_sub'  -1 ] [ p  ] = [ 0 ]
                # [ 1...1    0 ] [ v2 ]   [ 1 ]
                
                p_sol = solve_indifference(B_sub')
                q_sol = solve_indifference(A_sub) # A_sub * q = v1 * 1
                
                if p_sol !== nothing && q_sol !== nothing
                    p_full = zeros(m)
                    q_full = zeros(n)
                    p_full[s1_indices] = p_sol
                    q_full[s2_indices] = q_sol
                    
                    if is_valid_mixed(game, p_full, q_full, s1_indices, s2_indices)
                        # Avoid duplicates
                        if !any(eq -> isapprox(eq[1], p_full) && isapprox(eq[2], q_full), equilibria)
                            push!(equilibria, (p_full, q_full))
                        end
                    end
                end
            end
        end
    end
    
    return equilibria
end

# Helper to solve the indifference equations
function solve_indifference(M)
    k = size(M, 1)
    # System:
    # M[1,:] * x = v
    # M[2,:] * x = v
    # ...
    # Σ x = 1
    
    # M * x = v * 1  => M_i * x = v
    # This means (M_i - M_1) * x = 0 for i > 1
    # Plus Σ x = 1
    
    if k == 1
        return [1.0]
    end
    
    A_mat = ones(k, k)
    for i in 1:(k-1)
        A_mat[i, :] = M[i+1, :] .- M[1, :]
    end
    # Last row is the sum constraint
    A_mat[k, :] .= 1.0
    
    b_vec = zeros(k)
    b_vec[k] = 1.0
    
    try
        x = A_mat \ b_vec
        # Check if all x_i > 0 (non-negative and strictly positive in support)
        if all(val -> val >= -1e-9, x)
            return x
        end
    catch
        return nothing
    end
    return nothing
end

# Helper to check if a mixed strategy profile is a Nash Equilibrium
function is_valid_mixed(game, p, q, s1, s2)
    A = game.payoffs[1]
    B = game.payoffs[2]
    
    # Expected payoffs for player 1 for each strategy
    u1 = A * q
    max_u1 = maximum(u1)
    
    # Player 1 should only play strategies that give max_u1
    for i in 1:game.strategy_counts[1]
        if p[i] > 1e-9 && !isapprox(u1[i], max_u1, atol=1e-7)
            return false
        end
    end
    
    # Expected payoffs for player 2 for each strategy
    # u2[j] = Σ p_i * B[i, j] = p' * B[:, j]
    u2 = (p' * B)'
    max_u2 = maximum(u2)
    
    # Player 2 should only play strategies that give max_u2
    for j in 1:game.strategy_counts[2]
        if q[j] > 1e-9 && !isapprox(u2[j], max_u2, atol=1e-7)
            return false
        end
    end
    
    return true
end

# Simple combinations implementation to avoid external dependencies
function combinations(arr, k)
    n = length(arr)
    if k == 0 return [[]] end
    if k > n return [] end
    if k == n return [arr] end
    
    res = []
    # Include first element
    for c in combinations(arr[2:end], k-1)
        push!(res, vcat(arr[1], c))
    end
    # Exclude first element
    for c in combinations(arr[2:end], k)
        push!(res, c)
    end
    return res
end

end # module
